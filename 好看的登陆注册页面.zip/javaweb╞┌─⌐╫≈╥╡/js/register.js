window.onload = function() {
    var reguname = /^[a-zA-Z]{2,8}$/;
    var uname = document.querySelector('#uname');
    regexp(uname, reguname);

    function regexp(ele, reg) {
        ele.onblur = function() {
            if (reg.test(this.value)) {
                this.nextElementSibling.className = 'blue';
                this.nextElementSibling.innerHTML = '';
                this.style.border = '1px solid #16DAD1';
                this.style.boxShadow = 'inset 0 0 0 3px rgb(22 218 209 / 20%)';
            } else {
                if (this.value == '') {
                    this.nextElementSibling.className = 'red';
                    this.nextElementSibling.innerHTML = '请输入用户名';
                    this.style.border = '1px solid #FF6C93';
                    this.style.boxShadow = 'inset 0 0 0 3px rgb(255 108 147 / 20%)';
                } else {
                    this.nextElementSibling.className = 'red';
                    this.nextElementSibling.innerHTML = '请输入正确的用户名';
                    this.style.border = '1px solid #FF6C93';
                    this.style.boxShadow = 'inset 0 0 0 3px rgb(255 108 147 / 20%)';
                }
            }
        }
    };


}