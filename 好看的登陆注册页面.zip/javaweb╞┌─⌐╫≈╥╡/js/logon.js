window.onload = function() {
    var regtel = /^1[3|4|5|7|8]\d{9}$/;
    var regpaw = /^[a-zA-Z0-9]{6,16}$/;
    var reguname = /^[a-zA-Z]{2,8}$/;
    var tel = document.querySelector('#tel');
    var paw = document.querySelector('#paw');
    var uname = document.querySelector('#uname');
    var password = document.querySelector('#password');

    regexp(tel, regtel);
    regexp(paw, regpaw);
    regexp(uname, reguname);


    function regexp(ele, reg) {
        ele.onblur = function() {
            if (reg.test(this.value)) {
                this.nextElementSibling.className = 'blue';
                this.nextElementSibling.innerHTML = '输入正确';
                this.style.border = '1px solid #16DAD1';
                this.style.boxShadow = 'inset 0 0 0 3px rgb(22 218 209 / 20%)';
            } else {
                if (this.value == '') {
                    this.nextElementSibling.className = 'red';
                    this.nextElementSibling.innerHTML = '输入框不能为空';
                    this.style.border = '1px solid #FF6C93';
                    this.style.boxShadow = 'inset 0 0 0 3px rgb(255 108 147 / 20%)';
                } else {
                    this.nextElementSibling.className = 'red';
                    this.nextElementSibling.innerHTML = '你输入的格式有误';
                    this.style.border = '1px solid #FF6C93';
                    this.style.boxShadow = 'inset 0 0 0 3px rgb(255 108 147 / 20%)';
                }
            }
        }
    };

    password.onblur = function() {
        if (this.value == paw.value) {
            if (this.value == '') {
                this.nextElementSibling.className = 'red';
                this.nextElementSibling.innerHTML = '输入框不能为空';
                this.style.border = '1px solid #FF6C93';
                this.style.boxShadow = 'inset 0 0 0 3px rgb(255 108 147 / 20%)';
            } else {
                this.nextElementSibling.className = 'blue';
                this.nextElementSibling.innerHTML = '输入正确';
                this.style.border = '1px solid #16DAD1';
                this.style.boxShadow = 'inset 0 0 0 3px rgb(22 218 209 / 20%)';
            }
        } else {
            this.nextElementSibling.className = 'red';
            this.nextElementSibling.innerHTML = '两次密码不一致';
            this.style.border = '1px solid #FF6C93';
            this.style.boxShadow = 'inset 0 0 0 3px rgb(255 108 147 / 20%)';
        }
    }


}