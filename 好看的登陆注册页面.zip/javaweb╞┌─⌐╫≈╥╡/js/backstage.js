window.addEventListener('load', function() {
    var data = [{
        id: 1,
        ying: '正常',
        biao: '水果店',
        lian: '阙如',
        dian: '17364997211',
        fen: '租商铺',
        fa: '郭果',
        ren: '已认证',
        shijian: '02 - 11',
    }, {
        id: 2,
        ying: '正常',
        biao: '音乐吧',
        lian: '白桦',
        dian: '13748326655',
        fen: '租商铺',
        fa: '舒华',
        ren: '已认证',
        shijian: '02 - 08',
    }, {
        id: 3,
        ying: '待审',
        biao: '蛋糕店',
        lian: '梦琪',
        dian: '13546778241',
        fen: '找商铺',
        fa: '兴澄',
        ren: '未认证',
        shijian: '02 - 03',
    }, {
        id: 4,
        ying: '正常',
        biao: '火锅店',
        lian: '铭乐乐',
        dian: '19364552633',
        fen: '租商铺',
        fa: '阿布',
        ren: '已认证',
        shijian: '01 - 28',
    }, {
        id: 5,
        ying: '待审',
        biao: '奶茶店',
        lian: '蜜桃',
        dian: '16345518221',
        fen: '找商铺',
        fa: '昆型',
        ren: '已认证',
        shijian: '01 - 19',
    }, ];


    var tbody = document.querySelector('tbody');
    var uname = document.querySelector('.input-lg');
    var cha = document.querySelector('.btn-primary');

    setDate(data);

    function setDate(mydata) {
        tbody.innerHTML = '';
        mydata.forEach(function(value) {
            var tr = document.createElement('tr');
            tr.innerHTML = '<td>' + value.id + '</td><td>' + value.ying + '</td><td>' + value.biao + '</td><td>' + value.lian + '</td><td>' + value.dian + '</td><td>' + value.fen + '</td><td>' + value.fa + '</td><td>' + value.ren + '</td><td>' + value.shijian + '</td><td><a href="#" class="edit"><span class="glyphicon glyphicon-pencil"></span>编辑</a><a href="#" class="see"><span class="glyphicon glyphicon-trash"></span>删除</a></td>';
            tbody.appendChild(tr);
        });
    }


    cha.addEventListener('click', function() {
        var arr = [];
        data.some(function(value) {
            if (value.lian == uname.value) {
                arr.push(value);
                return true;
            }
        });
        setDate(arr);
    })
    var as = document.querySelectorAll('.see');
    for (var i = 0; i < as.length; i++) {
        as[i].onclick = function() {
            var conf = confirm('确定要删除吗？');
            if (conf == true) {
                tbody.removeChild(this.parentNode.parentNode)
                alert('删除成功');
            }
        }
    }
})