// window.addEventListener('load', function() {

//     var data = [{
//         id: 1,
//         pname: '北方的狼',
//         prick: '张三',
//         shouji: 17463994811,
//         shijian: '2019 - 10 - 20',
//         zhuangtai: '正常',
//     }, {
//         id: 2,
//         pname: '阿甘',
//         prick: '王华',
//         shouji: 13047827743,
//         shijian: '2019 - 02 - 27',
//         zhuangtai: '禁用',
//     }, {
//         id: 3,
//         pname: '杏花村',
//         prick: '旺妞',
//         shouji: 17354881165,
//         shijian: '2018 - 12 - 31',
//         zhuangtai: '正常',
//     }, {
//         id: 4,
//         pname: '蓝天很懒',
//         prick: '铭庆',
//         shouji: 14758294622,
//         shijian: '2018 - 09 - 17',
//         zhuangtai: '禁用',
//     }, {
//         id: 5,
//         pname: '冰岛的冰',
//         prick: '王鑫',
//         shouji: 15378115244,
//         shijian: '2018 - 08 - 27',
//         zhuangtai: '正常',
//     }]

//     var tbody = document.querySelector('tbody');
//     var uname = document.querySelector('#exampleInputName2');
//     var cha = document.getElementById('cha');
//     var reset = document.querySelector('.reset');

//     setDate(data);

//     function setDate(mydata) {
//         tbody.innerHTML = '';
//         mydata.forEach(function(value) {
//             var tr = document.createElement('tr');
//             tr.innerHTML = '<td>' + value.id + '</td><td>' + value.pname + '</td><td>' + value.prick + '</td><td>' + value.shouji + '</td><td>' + value.shijian + '</td><td>' + value.zhuangtai + '</td><td><a href="#" class="edit"><span class="glyphicon glyphicon-pencil"></span>编辑</a><a href="#" class="see"><span class="glyphicon glyphicon-trash"></span>删除</a><span class = "blue"> 更多</span><select><option>封禁</option> <option>解禁</option></select></td>';
//             tbody.appendChild(tr);
//         });
//     }

//     cha.addEventListener('click', function() {
//         var arr = [];
//         data.some(function(value) {
//             if (value.prick == uname.value) {
//                 arr.push(value);
//                 return true;
//             }
//         });
//         setDate(arr);
//     })

//     reset.addEventListener('click', function() {
//         uname.value = '';
//     })
//     var as = document.querySelectorAll('.see');
//     for (var i = 0; i < as.length; i++) {
//         as[i].onclick = function() {
//             var conf = confirm('确定要删除吗？');
//             if (conf == true) {
//                 tbody.removeChild(this.parentNode.parentNode)
//                 alert('删除成功');
//             }
//         }
//     }


// })